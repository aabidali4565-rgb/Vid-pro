@file:OptIn(UnstableApi::class)

package com.myeditor.app

import android.app.Application
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    var clips by mutableStateOf(listOf<Clip>())
        private set
    var selectedId by mutableStateOf<Long?>(null)
        private set
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    private var nextId = 1L

    val selected: Clip? get() = clips.firstOrNull { it.id == selectedId }

    fun select(id: Long) { selectedId = id }

    fun addMedia(uris: List<Uri>) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            for (uri in uris) {
                val type = ctx.contentResolver.getType(uri) ?: ""
                val isImage = type.startsWith("image")
                val dur = if (isImage) 10_000L else withContext(Dispatchers.IO) { videoDuration(uri) }
                val end = if (isImage) 3_000L else dur
                val clip = Clip(nextId++, uri, isImage, 0L, end, dur.coerceAtLeast(1000L))
                clips = clips + clip
                if (selectedId == null) selectedId = clip.id
            }
        }
    }

    private fun videoDuration(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    fun delete(id: Long) {
        clips = clips.filter { it.id != id }
        if (selectedId == id) selectedId = clips.firstOrNull()?.id
    }

    fun trim(id: Long, start: Long, end: Long) {
        if (end - start < 200) return
        clips = clips.map { if (it.id == id) it.copy(startMs = start, endMs = end) else it }
    }

    fun setSpeed(id: Long, speed: Float) {
        clips = clips.map { if (it.id == id) it.copy(speed = speed) else it }
    }

    /** posMs = playhead position inside the selected clip's preview */
    fun split(posMs: Long) {
        val c = selected ?: return
        val cut = c.startMs + posMs
        if (cut - c.startMs < 300 || c.endMs - cut < 300) return
        val a = c.copy(endMs = cut)
        val b = c.copy(id = nextId++, startMs = cut)
        clips = clips.flatMap { if (it.id == c.id) listOf(a, b) else listOf(it) }
        selectedId = a.id
    }

    fun export() {
        val list = clips
        if (list.isEmpty()) return
        val ctx = getApplication<Application>()
        exportState = ExportState.Running

        val edited = list.map { c ->
            if (c.isImage) {
                val d = c.endMs - c.startMs
                val item = MediaItem.Builder().setUri(c.uri).setImageDurationMs(d).build()
                EditedMediaItem.Builder(item)
                    .setDurationUs(d * 1000)
                    .setFrameRate(30)
                    .setEffects(Effects(emptyList(), listOf<Effect>(Presentation.createForHeight(1080))))
                    .build()
            } else {
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs)
                    .setEndPositionMs(c.endMs)
                    .build()
                val item = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(clipping).build()
                val audio = mutableListOf<AudioProcessor>()
                val video = mutableListOf<Effect>()
                if (c.speed != 1f) {
                    audio.add(SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) })
                    video.add(SpeedChangeEffect(c.speed))
                }
                video.add(Presentation.createForHeight(1080))
                EditedMediaItem.Builder(item).setEffects(Effects(audio, video)).build()
            }
        }

        val composition = Composition.Builder(EditedMediaItemSequence(edited)).build()
        val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")

        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch {
                        val uri = withContext(Dispatchers.IO) { saveToGallery(out) }
                        exportState = if (uri != null) ExportState.Done(uri)
                        else ExportState.Error("Gallery mein save nahi hua")
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    exportState = ExportState.Error(exportException.message ?: "Export fail")
                }
            })
            .build()
        transformer.start(composition, out.absolutePath)
    }

    private fun saveToGallery(file: File): Uri? {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MyEditor")
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
        return uri
    }
}
