package com.myeditor.app

import android.net.Uri

data class Clip(
    val id: Long,
    val uri: Uri,
    val isImage: Boolean,
    val startMs: Long,
    val endMs: Long,
    val durationMs: Long,
    val speed: Float = 1f
)

sealed interface ExportState {
    object Idle : ExportState
    object Running : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Error(val msg: String) : ExportState
}
