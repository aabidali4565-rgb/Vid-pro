# My Editor (Step 1)
Import video/images, trim, split, speed, delete, export (1080p).
Push to GitHub -> Actions tab -> Build APK -> download artifact.
